package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class LoginPage extends LeafTapsWrappers{
	
	public LoginPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test =test;
		//driver.getCurrentUrl();
		//driver.navigate().to("http://sso.bioezone.in/");
		
		
		/*if(!verifyTitle("https://sso.mylawally.com/")){
			reportStep("This is not Login Page", "FAIL");
		}	*/	
	}
	
	public LoginPage enterUserName(String data){
		enterById(prop.getProperty("Login.UserName.Id"), data);
		return this;
	}
	
	public LoginPage enterPassword(String data){
		enterById(prop.getProperty("Login.Password.Id"), data);
		return this;
	}
	
	public HomePage clicksignin(){
		clickById(prop.getProperty("Login.LoginButton.Id"));
		/*HomePage hp = new HomePage();
		return hp;*/		
		return new HomePage(driver, test);		
	}
	
	public LoginPage clickLoginforFailure(){
		clickById("btGoLogin");		
		/*HomePage hp = new HomePage();
		return hp;*/		
		return this;		
	}
	
	public LoginPage verifyLoginDetails(String text){
		verifyTextContainsById(prop.getProperty("Login.Error.Id"), text);
		return this;
	}
	public RegistrationPage clickCreateAccount(){
		
		clickByXpath(prop.getProperty("Login.CreateButton.Xpath"));
		return new RegistrationPage(driver,test);
	}

}



